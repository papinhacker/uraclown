package ru.vtb.static_data;

import ru.vtb.utils.DBHelper;
import ru.vtb.utils.common.Log;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.Map;
import java.util.Properties;

public class EnvConstants {

    public static final String FILE_SEPARATOR = FileSystems.getDefault().getSeparator();
    public static final String PROJECT_DIRECTORY = System.getProperty("user.dir");
    public static final String PROJECT_PATH = PROJECT_DIRECTORY + FILE_SEPARATOR;
    public static final String CORP_TO_JSON = "CORP_TO_JSON";
    public static final String FL_TO_JSON = "FL_TO_JSON";
    public static final String TERMINAL_TYPE = "TERMINAL_TYPE";
    public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
    private static final String PROP_PATH = System.getProperty("propsPath", "generator.properties");
    protected static final Properties PROPERTIES = getPropsForEnv();
    /* database data */
    public static final String DB_URI = getProperty("db.uri");
    public static final String DB_CLEARING_PATH = getProperty("db.clearing.path");
    public static final String DB_CLEARING_USER = getProperty("db.clearing.user");
    public static final String DB_CLEARING_PASSWORD = getProperty("db.clearing.password");
    public static final String DB_TRANSACTIONS_AGR_SRV_PATH = getProperty("db.trans.agr.srv.path");
    public static final String DB_TRANSACTIONS_AGR_SRV_USER = getProperty("db.trans.agr.srv.user");
    public static final String DB_TRANSACTIONS_AGR_SRV_PASSWORD = getProperty("db.trans.agr.srv.password");
    /* s3 data */
    public static final String S3_URI = getProperty("s3.uri");
    public static final String S3_PORT = getProperty("s3.port");
    public static final String S3_ACCESS_KEY = getProperty("s3.access.key");
    public static final String S3_SECRET_KEY = getProperty("s3.secret.key");
    public static final String S3_REGION = getProperty("s3.region");
    public static final String S3_PROTOCOL = getProperty("s3.protocol");
    public static final String S3_INPUT_BUCKET_NAME = getProperty("s3.bucket.in.name");
    /* generator params */
    public static final String TRANS_COUNT = getProperty("count");
    public static final boolean SEND_TO_S3 = Boolean.parseBoolean(getProperty("send.to.s3"));
    public static final String MASK_SUFFIX = getProperty("mask.suffix");
    /* generator params */
    public static final boolean DEBUG = Boolean.parseBoolean(getProperty("debug"));

    public static final Map<String, Boolean> CONVERT_CLEARING = DBHelper.getCovertClearingMapping();

    private static Properties getPropsForEnv() {
        Properties properties;

        try (FileReader reader = new FileReader(PROP_PATH)) {
            properties = new Properties();
            properties.load(reader);
        } catch (IOException e) {
            String err = String.format("Unable to read properties file. Reason is '%s'", e.getMessage());
            Log.error(err);
            throw new RuntimeException(err);
        }
        return properties;
    }

    protected static String getProperty(String key) {
        String prop = PROPERTIES.getProperty(key);
        if (prop == null) {
            throw new RuntimeException("Property '%s' must be provided in '%s'".formatted(key, PROP_PATH));
        }
        return prop;
    }
}
