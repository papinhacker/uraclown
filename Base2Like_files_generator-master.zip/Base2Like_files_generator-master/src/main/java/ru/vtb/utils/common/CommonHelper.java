package ru.vtb.utils.common;

import org.joda.time.DateTime;
import ru.vtb.utils.sql.SQLHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ThreadLocalRandom;

public class CommonHelper {

    private CommonHelper() {
    }

    public static String getNumericDayOfYearBeforeCurrentDate() {
        DateTime dateTime = new DateTime();
        return String.format("%03d",
                Integer.parseInt(dateTime.minusDays(ThreadLocalRandom.current().nextInt(1, dateTime.getDayOfYear()))
                        .dayOfYear().getAsString()));
    }

    public static <T> T getRandomFromList(List<T> list) {
        try {
            return list.get(ThreadLocalRandom.current().nextInt(list.size()));
        } catch (IndexOutOfBoundsException | IllegalArgumentException e) {
            throw new RuntimeException("Unable to get random element from list. Reason is: %s".formatted(e.getMessage()));
        }
    }
}
