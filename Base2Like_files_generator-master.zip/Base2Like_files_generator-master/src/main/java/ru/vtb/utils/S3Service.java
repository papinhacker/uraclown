package ru.vtb.utils;

import ru.vtb.static_data.EnvConstants;
import ru.vtb.utils.common.Log;
import software.amazon.awssdk.auth.credentials.AwsBasicCredentials;
import software.amazon.awssdk.auth.credentials.StaticCredentialsProvider;
import software.amazon.awssdk.core.internal.http.loader.DefaultSdkHttpClientBuilder;
import software.amazon.awssdk.http.SdkHttpClient;
import software.amazon.awssdk.http.SdkHttpConfigurationOption;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.*;
import software.amazon.awssdk.utils.AttributeMap;

import java.io.Closeable;
import java.io.IOException;
import java.net.URI;
import java.nio.file.Path;
import java.util.List;

public class S3Service implements Closeable {

    private S3Client s3Client;

    public S3Service() {
        init();
    }

    public void init() {
        SdkHttpClient httpClient = new DefaultSdkHttpClientBuilder()
                .buildWithDefaults(AttributeMap.builder()
                        .put(SdkHttpConfigurationOption.TRUST_ALL_CERTIFICATES, true)
                        .build());

        this.s3Client = S3Client.builder()
                .region(Region.of(EnvConstants.S3_REGION))
                .credentialsProvider(StaticCredentialsProvider.create(
                        AwsBasicCredentials.create(EnvConstants.S3_ACCESS_KEY, EnvConstants.S3_SECRET_KEY)))
                .endpointOverride(
                        URI.create(EnvConstants.S3_PROTOCOL + "://" + EnvConstants.S3_URI + ":" + EnvConstants.S3_PORT))
                .httpClient(httpClient)
                .forcePathStyle(true)
                .build();
    }

    public PutObjectResponse putObject(String bucketName, String keyPrefix, java.io.File file) {
        String key = keyPrefix + file.getName();
        Log.info(String.format(
                "Sending file '%s' to object '%s' in bucket '%s'", file.getName(), key, bucketName));
        PutObjectRequest request = PutObjectRequest.builder()
                .bucket(bucketName)
                .key(key)
                .build();

        return s3Client.putObject(request, Path.of(file.toURI()));
    }

    public List<String> getObjectsNames(String bucketName) {
        ListObjectsV2Request listObjectsV2Request = ListObjectsV2Request.builder()
                .bucket(bucketName)
                .build();
        ListObjectsV2Response listObjectsV2Response = s3Client.listObjectsV2(listObjectsV2Request);

        return listObjectsV2Response.contents().stream().map(S3Object::key).toList();
    }

    @Override
    public void close() throws IOException {
        this.s3Client.close();
    }
}
