package ru.vtb.utils;

import org.apache.commons.compress.archivers.*;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveOutputStream;
import org.apache.commons.io.IOUtils;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Path;

public class ZipUtils {

    private ZipUtils() {
    }

    public static File compressToZip(File fileToCompress, boolean deleteOriginal) {
        File resultFile = new File(fileToCompress.getPath() + ".zip");
        try (ArchiveOutputStream<ZipArchiveEntry> out = new ZipArchiveOutputStream(resultFile)) {
            ZipArchiveEntry entry = out.createArchiveEntry(fileToCompress, fileToCompress.getName());
            out.putArchiveEntry(entry);
            try (InputStream input = Files.newInputStream(fileToCompress.toPath())) {
                IOUtils.copy(input, out);
            }
            out.closeArchiveEntry();
            out.finish();
            if (deleteOriginal) {
                fileToCompress.deleteOnExit();
            }

        } catch (IOException e) {
            throw new RuntimeException(e.getMessage());
        }
        return resultFile;
    }

    public static void extractEntry(String archivePath, String entryName, String destinationPath) {
        try (InputStream input = Files.newInputStream(Path.of(archivePath));
             BufferedInputStream buffer = new BufferedInputStream(input);
             ArchiveInputStream<?> archive = new ArchiveStreamFactory()
                     .createArchiveInputStream(buffer)) {
            ArchiveEntry entry;
            while ((entry = archive.getNextEntry()) != null) {
                if (entry.getName().equals(entryName)) {
                    Path outFile = Path.of(destinationPath).resolve(entryName);
                    Files.createDirectories(outFile.getParent());
                    try (OutputStream os = Files.newOutputStream(outFile)) {
                        IOUtils.copy(archive, os);
                    }
                    break;
                }
            }
        } catch (IOException | ArchiveException e) {
            throw new RuntimeException("Unable to unarchive entry '%s' from archive '%s' to path '%s'%nReason is: %s"
                    .formatted(entryName, archivePath, destinationPath, e.getMessage()));
        }
    }
}
