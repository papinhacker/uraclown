package ru.vtb.utils;

import ru.vtb.utils.sql.SQLHelper;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static ru.vtb.static_data.EnvConstants.DEBUG;
import static ru.vtb.utils.sql.SQLHelper.BATM_CLEARING;
import static ru.vtb.utils.sql.SQLHelper.BATM_TRANSACTIONS_AGR_SRV;

public class DBHelper {

    private static final String FORMATTED_TRANS_AGR_SRV_TERMINALS = getTransAgrSrvTerminalsString();

    private static String getTransAgrSrvTerminalsString() {
        String query = """
                select atm_id
                from devices_acc
                where device_type = 'atm'
                """;
        return formatListForInStatement(getFirstColumn(new SQLHelper(BATM_TRANSACTIONS_AGR_SRV).getRowLinesFromDB(query, DEBUG)));
    }

    public static List<String> getFlToJsonTerminals() {
        String query = """
                select atm_id
                from device
                where fl_to_json = 'Y'
                and location_type = 'Y'
                and atm_migration = 'Y'
                and atm_id in (%s)
                """;
        return getFirstColumn(new SQLHelper(BATM_CLEARING).getRowLinesFromDB(query.formatted(FORMATTED_TRANS_AGR_SRV_TERMINALS), DEBUG));
    }

    public static List<String> getCorpToJsonTerminals() {
        String query = """
                select atm_id
                from device
                where corp_to_json = 'Y'
                and atm_migration = 'Y'
                and atm_id in (%s)
                """;
        return getFirstColumn(new SQLHelper(BATM_CLEARING).getRowLinesFromDB(query.formatted(FORMATTED_TRANS_AGR_SRV_TERMINALS), DEBUG));
    }

    public static Map<String, Boolean> getCovertClearingMapping() {
        Map<String, Boolean> result = new HashMap<>();
        String query = """
                select clearing, is_json
                from convert_clearing
                """;
        var rawData = new SQLHelper(BATM_CLEARING).getRowLinesFromDB(query, true);
        for (var rawMap : rawData) {
            result.put(rawMap.get("clearing").toString(), Boolean.parseBoolean(rawMap.get("is_json").toString()));
        }
        return result;
    }

    private static List<String> getFirstColumn(List<Map<String, Object>> table) {
        List<String> result = new ArrayList<>();
        table.forEach(s -> result.add(s.values().stream().map(Object::toString).toList().get(0)));
        return result;
    }

    private static String formatListForInStatement(List<String> list) {
        return String.join(",", list.stream().map(s -> "'" + s + "'").toList());
    }
}
