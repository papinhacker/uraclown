package ru.vtb.utils;

import ru.vtb.static_data.B2LMask;
import ru.vtb.static_data.Bin;
import ru.vtb.static_data.TransactionDto;
import ru.vtb.utils.common.CommonHelper;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static ru.vtb.static_data.B2LMask.D_038cto;
import static ru.vtb.static_data.B2LMask._038cts;
import static ru.vtb.static_data.EnvConstants.ACCOUNT_NUMBER;
import static ru.vtb.static_data.EnvConstants.PROJECT_PATH;

public class Base2LikeHelper {

    private Base2LikeHelper() {
    }

    public static List<TransactionDto> getBase2LikeTransactionsFromFile(String path) {
        List<TransactionDto> transactions = new LinkedList<>();

        List<String> lines = FileHelper.readLinesFromTextFile(path);
        TransactionDto currentTransaction = new TransactionDto();
        for (String line : lines) {
            if (line.substring(0, 2).matches("06|26|07|27|99|92") && !currentTransaction.addLine(line)) {
                transactions.add(currentTransaction);
                currentTransaction = new TransactionDto();
                currentTransaction.addLine(line);
            }
        }
        return transactions;
    }

    public static File generateBase2LikeFile(String fileName, Map<String, String> data, int count,
                                             int... additionalTrashTransactionsPercentage) {
        int plusTrashTransPercentage = additionalTrashTransactionsPercentage.length > 0 ? additionalTrashTransactionsPercentage[0] : 0;
        List<String> lines = new ArrayList<>();
        String path = PROJECT_PATH + fileName;
        lines.add("9088888424292                                                               024                                                                                         ");
        List<TransactionDto> transactions = generateBase2LikeTransactions(data, count, fileName, plusTrashTransPercentage);
        for (TransactionDto dto : transactions) {
            lines.addAll(dto.getAllInitializedLines());
            lines.add("5000888884888884WAY4  78888844292900000172827071                                                                                                                        ");
            lines.add("5001EMB_NAME=KUDRYAVTSEV/PANFIL;                                                                                                                                        ");
        }
        lines.add("91008888840000000000000030000000000000001200000100000000008800000002400001000000024000000000000000000000000000300000000000000000000000000000000000000000000000000       ");
        lines.add("920088888400000000000000300000000000000012000001000000000089000000        000000025000000000000000000000000000300000000000000000000000000000000000000000000000000       ");
        return FileHelper.writeLinesToFile(lines, path);
    }

    public static File generateBase2LikeFile(String path, List<TransactionDto> transactions) {
        List<String> lines = new ArrayList<>();
        for (TransactionDto dto : transactions) {
            lines.addAll(dto.getAllInitializedLines());
        }
        lines.add("9999");
        return FileHelper.writeLinesToFile(lines, path);
    }

    private static List<TransactionDto> generateBase2LikeTransactions(Map<String, String> data, int count,
                                                                      String filename, int additionalTrashTransactionsPercentage) {
        List<TransactionDto> transactions = new ArrayList<>();
        B2LMask mask = B2LMask.recognize(filename);
        List<Bin> bins = mask.equals(D_038cto) ? Arrays.asList(Bin.values()) : Bin.getOnlyInternalVtbBins();
        data.put(ACCOUNT_NUMBER, CommonHelper.getRandomFromList(bins).generateRandAccNum());

        int cashInQuota;
        int withdrawQuota;
        int reversalQuota = (count / 100) + 2;
        reversalQuota = reversalQuota % 2 == 0 ? reversalQuota : reversalQuota + 1;
        boolean cashInReversalFlag;
        boolean withdrawReversalFlag;

        switch (mask) {
            case _298cto, VTB24_038cto -> {
                withdrawQuota = count * 70 / 100;
                cashInQuota = count - withdrawQuota;
                cashInReversalFlag = false;
                withdrawReversalFlag = true;
            }
            case CORP_038cto -> {
                cashInQuota = 0;
                withdrawQuota = count;
                cashInReversalFlag = false;
                withdrawReversalFlag = true;
            }
            case CORP_038ctd, OPS_038ctd, _038cts -> {
                cashInQuota = count;
                withdrawQuota = 0;
                cashInReversalFlag = false;
                withdrawReversalFlag = false;
            }
            case D_038cto -> {
                withdrawQuota = count * 70 / 100;
                cashInQuota = count - withdrawQuota;
                cashInReversalFlag = true;
                withdrawReversalFlag = true;
            }
            default -> throw new RuntimeException("Unable to set transactions quotas for '%s' file".formatted(filename));
        }

        int otherQuota = count * additionalTrashTransactionsPercentage / 100;

        while (cashInQuota != 0 || withdrawQuota != 0 || otherQuota != 0) {
            TransactionDto dto;
            int random = ThreadLocalRandom.current().nextInt(5);
            switch (random) {
                case 0 -> {
                    if (cashInQuota >= 1) {
                        dto = getNewCashInTransactionReference().generateRandomData().setSpecificData(data);
                        if (mask.equals(_038cts)) {
                            dto = getNewSelfCollectionCashInTransactionReference(data);
                        }
                        transactions.add(dto);
                        cashInQuota = cashInQuota - 1;
                    }
                }
                case 1 -> {
                    if (cashInQuota >= 2 && cashInReversalFlag && reversalQuota >= 2) {
                        transactions.addAll(getBundleOfCashInAndCashInReversedTransactions(data));
                        cashInQuota = cashInQuota - 2;
                        reversalQuota = reversalQuota - 2;
                    }
                }
                case 2 -> {
                    if (withdrawQuota >= 1) {
                        dto = getNewWithdrawTransactionReference().generateRandomData().setSpecificData(data);
                        transactions.add(dto);
                        withdrawQuota = withdrawQuota - 1;
                    }
                }
                case 3 -> {
                    if (withdrawQuota >= 2 && withdrawReversalFlag && reversalQuota >= 2) {
                        transactions.addAll(getBundleOfWithdrawalAndWithdrawalReversedTransactions(data));
                        withdrawQuota = withdrawQuota - 2;
                        reversalQuota = reversalQuota - 2;
                    }
                }
                case 4 -> {
                    if (otherQuota >= 1) {
                        transactions.add(getTrashTransactionReference());
                        otherQuota = otherQuota - 1;
                    }
                }
                default -> throw new IndexOutOfBoundsException("Random number generated out of bound");
            }

        }
        return transactions;
    }

    public static String generateBase2LikeFileName(B2LMask prefix, String suffix) {
        return prefix.getName().concat(suffix);
    }

    public static TransactionDto getNewCashInTransactionReference() {
        TransactionDto dto = new TransactionDto();
        dto.setZeroLine("06204893470540070387000   78888844292900000172751100418511018000000010000643000000010000643VTB Bank                 Moskva       RU 601100000     1009N2594925 2 0500000");
        dto.setFirstLine("0621            000000                                                          VB24           387053  000000000000  000000  0 9                             000000000  ");
        dto.setThirdLine("0623            CR                                                                                                                                                      ");
        dto.setFifthLine("0625               00000001000064300        0000 000000000000                              000000000000000 0000000000000000000000000000              0000000000000000   ");
        dto.setSeventhLine("062720001241018604020643        C8E9A81D01EE3C003D97CBB3ECC81780010A800004000003A000000000000000000F030000160000000006000000D32CFE84                                    ");
        dto.setEighthLine("0628202410181430434292670025872503001387053  VB24           16    q 888884      8023Altufevskoe shosse 1          127562    201                    00000000             ");
        return dto;
    }

    public static TransactionDto getNewSelfCollectionCashInTransactionReference(Map<String, String> data) {
        TransactionDto dto = new TransactionDto();
        dto.setZeroLine("06200000000000000000000   78888846209905532827977100418510728000000000000   000000010000643Bank VTB (PAO)           g. Moskva    RU 601200000     1009NI9AE9K5 0 0100000");
        dto.setFirstLine("0621            000000                                                          VB24           375273  000000000000  000000  0 9                             000000000  ");
        dto.setThirdLine("0623            BBAT=GA;F103=8;F104=8729984720;F111.2=000000000220;F111.4=00000;F111.5=621350898620980306;                                                              ");
        dto.setEighthLine("0628202607281835380000000002200000   375273  VB24           00    L               00D. 1, SH. ALTUF'EVSKOE        127106                           00000000             ");
        return dto.setSpecificData(data).addSelfCollectionAttributes();
    }

    public static TransactionDto getNewCashInReversedTransactionReference() {
        TransactionDto dto = new TransactionDto();
        dto.setZeroLine("26204893470540070387000   78888844292900000172751100418511018000000010000643000000010000643VTB Bank                 Moskva       RU 601100000     1009N2594925 2 0500000");
        dto.setFirstLine("2621            000000                                                          VB24           387053  000000000000  000000  0 9                             000000000  ");
        dto.setThirdLine("2623            CR                                                                                                                                                      ");
        dto.setFifthLine("2625               00000001000064300        0000 000000000000                              000000000000000 0000000000000000000000000000              0000000000000000   ");
        dto.setSeventhLine("262720001241018604020643        C8E9A81D01EE3C003D97CBB3ECC81780010A800004000003A000000000000000000F030000160000000006000000D32CFE84                                    ");
        dto.setEighthLine("2628202410181430434292670025872503001387053  VB24           16    q 888884      8023Altufevskoe shosse 1          127562    201                    00000000             ");
        return dto;
    }

    public static TransactionDto getNewWithdrawTransactionReference() {
        TransactionDto dto = new TransactionDto();
        dto.setZeroLine("07005368292015341868000   78888844292900000172868100418511018000000010000643000000010000643VTB Bank CASH            Moskva       RU 601100000   9 1009N2908305 2 0500000");
        dto.setFirstLine("0701            000000                                                          VB24           387053  000000000000  000000  0 9 0                           000000000  ");
        dto.setFifthLine("0705               00000001000064300        0000 000000000000                              000000000000000 0000000000000000000000000000              0000000000000000   ");
        dto.setSeventhLine("070701001241018604020643        6602E0B3014E39008F9B055AEDF5107F10A08000040000000322000000000100000000000000000000000100FF                                              ");
        dto.setEighthLine("0708202410181448354292670127103103001387053  VB24           16    q 888884      8018Altufevskoe shosse 1          127562    201                    00000000             ");
        return dto;
    }

    public static TransactionDto getNewWithdrawReversedTransactionReference() {
        TransactionDto dto = new TransactionDto();
        dto.setZeroLine("27005368292015341868000   78888844292900000172868100418511018000000010000643000000010000643VTB Bank CASH            Moskva       RU 601100000   9 1009N2908305 2 0500000");
        dto.setFirstLine("2701            000000                                                          VB24           387053  000000000000  000000  0 9 0                           000000000  ");
        dto.setFifthLine("2705               00000001000064300        0000 000000000000                              000000000000000 0000000000000000000000000000              0000000000000000   ");
        dto.setSeventhLine("270701001241018604020643        6602E0B3014E39008F9B055AEDF5107F10A08000040000000322000000000100000000000000000000000100FF                                              ");
        dto.setEighthLine("2708202410181448354292670127103103001387053  VB24           16    q 888884      8018Altufevskoe shosse 1          127562    201                    00000000             ");
        return dto;
    }

    public static TransactionDto getTrashTransactionReference() {
        TransactionDto dto = new TransactionDto();
        dto.setZeroLine("05102200240221266071000   78888844292900000172496100418511018000000100000643000000100000643VTB Bank                 Moskva       RU 653800000     1009N2791295 2 0500000");
        dto.setFirstLine("0511            000000                                                          VB24           387053  000000000000  000000  0 9                             000000000  ");
        dto.setFifthLine("0515               00000010000064300        0000 000000000000                              000000000000000 0000000000000000000000000000              0000000000000000   ");
        dto.setSeventhLine("051700091241018604020643        889FA654038C39000A48F6B84E089DF5A5018000040000A03000A00000001000000002B924F6CD2CA5670F10010000000000000000000000000000                  ");
        dto.setEighthLine("0518202410181208514292670127013012091387053  VB24           16    q 888884      8032Altufevskoe shosse 1          127562    206                    00000000             ");
        return dto;
    }

    public static String convertB2lFileNameToUfx(String b2l) {
        String currentYear = new SimpleDateFormat("yyyy").format(new Date());
        return b2l
                .replace("CORP_", "")
                .replace("D_038", "238")
                .replace("VTB24_038", "138")
                .replace("cto", "ctoufx")
                .replace("ctd", "ctdufx")
                .replace("cta", "ctaufx")
                .concat("_").concat(currentYear).concat(".xml");
    }

    public static String convertB2lFileNameToJsonUfx(String b2l) {
        String currentYear = new SimpleDateFormat("yyyy").format(new Date());
        return b2l.concat("_").concat(currentYear).concat(".json");
    }

    public static TransactionDto copyTransactionData(TransactionDto from, TransactionDto to) {
        if (to.getAllInitializedLines().isEmpty() || from.getAllInitializedLines().isEmpty()) {
            throw new RuntimeException("Both classes must be initialized before copying transaction data");
        }
        to.setTransactionDate(from.getTransactionDate());
        to.setTransactionTime(from.getTransactionTime());
        to.setAcquirerReferenceNumber(from.getAcquirerReferenceNumber());
        to.setAuthorizationCode(from.getAuthorizationCode());
        to.setRetrievalReferenceNumber(from.getRetrievalReferenceNumber());
        to.setTransactionIdentifier(from.getTransactionIdentifier());
        to.setMerchantCategoryCode(from.getMerchantCategoryCode());
        to.setMerchantCountryCode(from.getMerchantCountryCode());
        to.setMerchantCity(from.getMerchantCity());
        to.setMerchantName(from.getMerchantName());
        to.setCardAcceptorID(from.getCardAcceptorID());
        to.setTerminalID(from.getTerminalID());
        to.setAccountNumber(from.getAccountNumber());
        to.setCardExpirationDate(from.getCardExpirationDate());
        to.setDestinationChannel(from.getDestinationChannel());
        to.setDestinationCurrencyCode(from.getDestinationCurrencyCode());
        to.setDestinationAmount(from.getDestinationAmount());
        to.setDataContent(from.getDataContent());
        to.setSurchargeAmount(from.getSurchargeAmount());
        return to;
    }

    public static List<TransactionDto> getBundleOfWithdrawalAndWithdrawalReversedTransactions(Map<String, String> data) {
        TransactionDto withdrawTransaction = Base2LikeHelper.getNewWithdrawTransactionReference().generateRandomData();
        withdrawTransaction.setSpecificData(data);
        TransactionDto withdrawReversedTransaction = Base2LikeHelper.getNewWithdrawReversedTransactionReference();
        Base2LikeHelper.copyTransactionData(withdrawTransaction, withdrawReversedTransaction);
        return List.of(withdrawTransaction, withdrawReversedTransaction);
    }

    public static List<TransactionDto> getBundleOfCashInAndCashInReversedTransactions(Map<String, String> data) {
        TransactionDto cashInTransaction = Base2LikeHelper.getNewCashInTransactionReference().generateRandomData();
        cashInTransaction.setSpecificData(data);
        TransactionDto cashInReversedTransaction = Base2LikeHelper.getNewCashInReversedTransactionReference();
        Base2LikeHelper.copyTransactionData(cashInTransaction, cashInReversedTransaction);
        return List.of(cashInTransaction, cashInReversedTransaction);
    }

    public static List<TransactionDto> getAllTransactionTypes(Map<String, String> data) {
        var cashIn = getNewCashInTransactionReference().setSpecificData(data);
        var bundle = new ArrayList<>(getBundleOfWithdrawalAndWithdrawalReversedTransactions(data));
        bundle.add(cashIn);
        return bundle;
    }
}
