package ru.vtb.app;

import ru.vtb.utils.Base2LikeHelper;
import ru.vtb.utils.S3Service;
import ru.vtb.utils.ZipUtils;
import ru.vtb.utils.common.CommonHelper;
import ru.vtb.utils.common.Log;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ThreadLocalRandom;

import static ru.vtb.static_data.B2LMask.*;
import static ru.vtb.static_data.EnvConstants.*;

/**
 *
 */
public class Main {

    public static void main(String[] args) {
        String fileSuffix = generateFileSuffix();
        Log.info("Starting B2L generator with postfix " + fileSuffix);
        List<File> generated = generateB2lFiles(Integer.parseInt(TRANS_COUNT), fileSuffix);
        Log.info("B2L files were successfully generated");
        sendToS3(generated);
        listFilesInS3();
    }

    private static List<File> generateB2lFiles(int count, String suffix) {
        List<File> result = new ArrayList<>();

        String b2l298cto = Base2LikeHelper.generateBase2LikeFileName(_298cto, suffix);
        String b2lCORP_038cto = Base2LikeHelper.generateBase2LikeFileName(CORP_038cto, suffix);
        String b2lCORP_038ctd = Base2LikeHelper.generateBase2LikeFileName(CORP_038ctd, suffix);
        String b2lVTB24_038cto = Base2LikeHelper.generateBase2LikeFileName(VTB24_038cto, suffix);
        String b2lD_038cto = Base2LikeHelper.generateBase2LikeFileName(D_038cto, suffix);
        String b2lOPS_038ctd = Base2LikeHelper.generateBase2LikeFileName(OPS_038ctd, suffix);

        String b2l038cts = Base2LikeHelper.generateBase2LikeFileName(_038cts, suffix);

        int additionalTrashTransactionsPercentage = 5;

        int part = count / 6;
        int iOPS_038ctd = count - (part * 5);
        int i038cts = count * 5 / 100;

        boolean deleteOriginalAfterCompression = !DEBUG;
        if (CONVERT_CLEARING.get(_298cto.getName())) {
            File f0 = Base2LikeHelper.generateBase2LikeFile(b2l298cto,
                    new HashMap<>(Map.of(TERMINAL_TYPE, FL_TO_JSON)),
                    part,
                    additionalTrashTransactionsPercentage);
            result.add(f0);
        }

        if (CONVERT_CLEARING.get(CORP_038cto.getName())) {
            File f1 = Base2LikeHelper.generateBase2LikeFile(b2lCORP_038cto,
                    new HashMap<>(Map.of(TERMINAL_TYPE, CORP_TO_JSON)),
                    part,
                    additionalTrashTransactionsPercentage);
            f1 = ZipUtils.compressToZip(f1, deleteOriginalAfterCompression);
            result.add(f1);
        }

        if (CONVERT_CLEARING.get(CORP_038ctd.getName())) {
            File f2 = Base2LikeHelper.generateBase2LikeFile(b2lCORP_038ctd,
                    new HashMap<>(Map.of(TERMINAL_TYPE, CORP_TO_JSON)),
                    part,
                    additionalTrashTransactionsPercentage);
            f2 = ZipUtils.compressToZip(f2, deleteOriginalAfterCompression);
            result.add(f2);
        }

        if (CONVERT_CLEARING.get(VTB24_038cto.getName())) {
            File f3 = Base2LikeHelper.generateBase2LikeFile(b2lVTB24_038cto,
                    new HashMap<>(Map.of(TERMINAL_TYPE, FL_TO_JSON)),
                    part,
                    additionalTrashTransactionsPercentage);
            f3 = ZipUtils.compressToZip(f3, deleteOriginalAfterCompression);
            result.add(f3);
        }

        if (CONVERT_CLEARING.get(D_038cto.getName())) {
            File f4 = Base2LikeHelper.generateBase2LikeFile(b2lD_038cto,
                    new HashMap<>(Map.of(TERMINAL_TYPE, FL_TO_JSON)),
                    part,
                    additionalTrashTransactionsPercentage);
            f4 = ZipUtils.compressToZip(f4, deleteOriginalAfterCompression);
            result.add(f4);
        }

        if (CONVERT_CLEARING.get(OPS_038ctd.getName())) {
            File f5 = Base2LikeHelper.generateBase2LikeFile(b2lOPS_038ctd,
                    new HashMap<>(Map.of(TERMINAL_TYPE, FL_TO_JSON)),
                    iOPS_038ctd,
                    additionalTrashTransactionsPercentage);
            f5 = ZipUtils.compressToZip(f5, deleteOriginalAfterCompression);
            result.add(f5);
        }

        if (CONVERT_CLEARING.get(_038cts.getName())) {
            File f6 = Base2LikeHelper.generateBase2LikeFile(b2l038cts,
                    new HashMap<>(Map.of(TERMINAL_TYPE, CORP_TO_JSON)),
                    i038cts,
                    0);
            result.add(f6);
        }
        return result;
    }

    private static void sendToS3(List<File> files) {
        if (files.isEmpty()) {
            throw new RuntimeException("0 files were generated. Check 'convert_clearing' table");
        }
        try (S3Service s3 = new S3Service()) {
            if (SEND_TO_S3) {
                Log.info("Start sending files to S3");
                for (File file : files) {
                    s3.putObject(S3_INPUT_BUCKET_NAME, "batm_output/", file);
                }
            }
        } catch (IOException e) {
            throw new RuntimeException("Unable to send files to S3 object storage. Reason is: " + e.getMessage());
        }
    }

    private static void listFilesInS3() {
        try (S3Service s3 = new S3Service()) {
            if (DEBUG) {
                Log.debug("Objects listing in bucket '%s'".formatted(S3_INPUT_BUCKET_NAME));
                s3.getObjectsNames(S3_INPUT_BUCKET_NAME).forEach(Log::debug);
            }
        } catch (IOException ignored) {

        }
    }

    private static String generateFileSuffix() {
        if (Objects.nonNull(MASK_SUFFIX) && !MASK_SUFFIX.isBlank()) {
            return MASK_SUFFIX;
        }
        List<Integer> ints = new ArrayList<>();
        ints.add(ThreadLocalRandom.current().nextInt(1, 6));
        ints.add(ThreadLocalRandom.current().nextInt(21, 26));

        int fileNumber = ints.get(ThreadLocalRandom.current().nextInt(ints.size()));
        String dayInYear = CommonHelper.getNumericDayOfYearBeforeCurrentDate();
        return String.format("%02d", fileNumber)
                .concat(".")
                .concat(dayInYear);
    }
}
