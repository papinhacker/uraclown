package ru.vtb.util.suite_models;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

import java.util.Objects;

@XmlAccessorType(XmlAccessType.FIELD)
public class TestItem {

    @XmlElement(name = "classes")
    private Classes classes;

    @XmlAttribute
    private String name;

    public String getName() {
        return name;
    }

    public void setClasses(Classes classes) {
        this.classes = classes;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Classes getClasses() {
        return classes;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof TestItem testItem)) return false;
        return getClasses().equals(testItem.getClasses()) && getName().equals(testItem.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getClasses(), getName());
    }
}