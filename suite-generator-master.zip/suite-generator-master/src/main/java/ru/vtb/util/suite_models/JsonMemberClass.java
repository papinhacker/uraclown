package ru.vtb.util.suite_models;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;
import jakarta.xml.bind.annotation.XmlElement;

import java.util.Objects;

@XmlAccessorType(XmlAccessType.FIELD)
public class JsonMemberClass {

    @XmlElement(name = "methods")
    private Methods methods;

    @XmlAttribute(name = "name")
    private String name;

    public Methods getMethods() {
        return methods;
    }

    public void setMethods(Methods methods) {
        this.methods = methods;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof JsonMemberClass that)) return false;
        return getMethods().equals(that.getMethods()) && getName().equals(that.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getMethods(), getName());
    }
}