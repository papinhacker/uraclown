package ru.vtb.util;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Marshaller;
import org.w3c.dom.Document;
import ru.vtb.util.suite_models.Suite;
import ru.vtb.util.suite_models.TestItem;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import javax.xml.transform.OutputKeys;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import java.io.File;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import static ru.vtb.App.suiteFiles;

public class SuiteGenerator {
    private SuiteGenerator() {}

    public static void generateSuite(String pathTo, List<String> suites, List<String> cases) {
        String suiteName = cases.isEmpty() ? String.join("/", suites) : "custom-suite";
        List<TestItem> filteredBuff = new LinkedList<>();
        if (!cases.isEmpty()) {
            List<TestItem> allTests = new LinkedList<>();
            for (File file : suiteFiles) {
                List<TestItem> suiteTests = FileHelper.deserializeXmlToObject(file).getTest();
                if (suiteTests != null && !suiteTests.isEmpty())
                    allTests.addAll(suiteTests);
            }
            filteredBuff = allTests.stream()
                    .filter(t -> cases.contains(t.getName()))
                    .toList();
        }
        List<TestItem> filtered = new ArrayList<>(filteredBuff);
        // add cases from provided suites
        if (!suites.isEmpty()) {
            for (File file : suiteFiles) {
                if (suites.contains(file.getName())) {
                    List<TestItem> suiteTests = FileHelper.deserializeXmlToObject(file).getTest();
                    if (suiteTests != null && !suiteTests.isEmpty())
                        filtered.addAll(suiteTests);
                }
            }
        }

        filtered = filtered.stream().distinct().toList();

        if (filtered.isEmpty()) {
            throw new RuntimeException("Unable to generate XML suite without tests");
        }

        if (suiteName.toLowerCase().contains("singlethread")) {
            generateXml(new Suite(filtered, suiteName, "none"), pathTo);
        } else generateXml(new Suite(filtered, suiteName, "methods"), pathTo);
    }

    private static void generateXml(Suite suite, String pathTo) {
        try {
            JAXBContext context = JAXBContext.newInstance(Suite.class);
            Marshaller marshaller = context.createMarshaller();
            marshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);
            marshaller.setProperty(Marshaller.JAXB_ENCODING, "UTF-8");

            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            Document document = db.newDocument();
            marshaller.marshal(suite, document);

            TransformerFactory tf = TransformerFactory.newInstance();
            Transformer transformer = tf.newTransformer();

            transformer.setOutputProperty(OutputKeys.INDENT, "yes");
            transformer.setOutputProperty("{http://xml.apache.org/xslt}indent-amount", "4");
            transformer.setOutputProperty(OutputKeys.ENCODING, "UTF-8");
            transformer.setOutputProperty(OutputKeys.DOCTYPE_SYSTEM, "https://testng.org/testng-1.0.dtd");

            String name = suite.getParallel().equals("none") ? "customSingleThread.xml" : "custom.xml";
            File output = new File(pathTo + name);
            transformer.transform(new DOMSource(document), new StreamResult(output));
        } catch (TransformerException | JAXBException | ParserConfigurationException e) {
            throw new RuntimeException("Unable to generate XML suite. Reason is: " + e.getMessage());
        }
    }
}
