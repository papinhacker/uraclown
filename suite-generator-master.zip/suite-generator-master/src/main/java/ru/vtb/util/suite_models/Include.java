package ru.vtb.util.suite_models;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlAttribute;

import java.util.Objects;

@XmlAccessorType(XmlAccessType.FIELD)
public class Include{

	@XmlAttribute(name = "name")
	private String name;

	public String getName() {
		return name;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Include include)) return false;
		return getName().equals(include.getName());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getName());
	}

	public void setName(String name) {
		this.name = name;
	}
}