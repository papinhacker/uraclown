package ru.vtb.util;

import jakarta.xml.bind.JAXBContext;
import jakarta.xml.bind.JAXBException;
import jakarta.xml.bind.Unmarshaller;
import org.w3c.dom.Document;
import org.xml.sax.SAXException;
import ru.vtb.util.suite_models.Suite;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.parsers.ParserConfigurationException;
import java.io.File;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;


public class FileHelper {
    private FileHelper() {}

    public static String readFile(File file) {
        try {
            return Files.readString(file.toPath());
        } catch (IOException e) {
            throw new RuntimeException("Unable to read file: " + file.toPath());
        }
    }

    public static File getFileByName(List<File> files, String name) {
        for (File file : files) {
            if (file.getName().equals(name)) {
                return file;
            }
        }
        return null;
    }

    public static String completePath(String path) {
        String sep = FileSystems.getDefault().getSeparator();
        return System.getProperty("user.dir") + sep + path;
    }

    public static List<String> readLinesFormFile(File file) {
        try {
            return Files.readAllLines(file.toPath());
        } catch (IOException e) {
            throw new RuntimeException("Unable to read file: " + file.toPath());
        }
    }

    public static Suite deserializeXmlToObject(File xml) {
        try {
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            dbf.setFeature("http://apache.org/xml/features/disallow-doctype-decl", false); // allow DOCTYPE
            dbf.setFeature("http://xml.org/sax/features/external-general-entities", false);
            dbf.setFeature("http://xml.org/sax/features/external-parameter-entities", false);
            dbf.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false);

            dbf.setXIncludeAware(false);
            dbf.setExpandEntityReferences(false);

            DocumentBuilder db = dbf.newDocumentBuilder();
            Document doc = db.parse(xml);
            JAXBContext context = JAXBContext.newInstance(Suite.class);
            Unmarshaller unmarshaller = context.createUnmarshaller();
            return (Suite) unmarshaller.unmarshal(doc);
        } catch (JAXBException | SAXException | ParserConfigurationException | IOException e) {
            throw new RuntimeException("Unable to deserialize xml '%s' to object Reason is: %s".formatted(xml, e.getMessage()));
        }
    }

    public static List<File> getAllSuites(String pathFrom) {
        List<File> files = new ArrayList<>();
        listAllFilesFromDirectoriesAndSubDirectories(pathFrom, files);
        return files;
    }

    private static void listAllFilesFromDirectoriesAndSubDirectories(String path, List<File> files) {
        File directory = new File(path);

        File[] fls = directory.listFiles();
        if (fls != null) {
            for (File file : fls) {
                if (file.isFile()) {
                    files.add(file);
                } else if (file.isDirectory()) {
                    listAllFilesFromDirectoriesAndSubDirectories(file.getAbsolutePath(), files);
                }
            }
        }
    }
}
