package ru.vtb.util.suite_models;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;

import java.util.Objects;

@XmlAccessorType(XmlAccessType.FIELD)
public class Classes {

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Classes classes)) return false;
        return getJsonMemberClass().equals(classes.getJsonMemberClass());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getJsonMemberClass());
    }

    @XmlElement(name = "class")
    private JsonMemberClass jsonMemberClass;

    public JsonMemberClass getJsonMemberClass() {
        return jsonMemberClass;
    }

    public void setJsonMemberClass(JsonMemberClass jsonMemberClass) {
        this.jsonMemberClass = jsonMemberClass;
    }
}