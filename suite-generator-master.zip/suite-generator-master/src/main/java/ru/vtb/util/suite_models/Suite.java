package ru.vtb.util.suite_models;

import jakarta.xml.bind.annotation.*;

import java.util.List;
import java.util.Objects;

@XmlRootElement(name = "suite")
@XmlAccessorType(XmlAccessType.FIELD)
public class Suite {

    public Suite() {
    }

    public Suite(List<TestItem> test, String name, String parallel) {
        this.test = test;
        this.name = name;
        this.parallel = parallel;
    }

    @XmlElement(name = "test")
    private List<TestItem> test;

    @XmlAttribute
    private String name;

    @XmlAttribute
    private String parallel;

    public String getParallel() {
        return parallel;
    }

    public void setParallel(String parallel) {
        this.parallel = parallel;
    }

    public List<TestItem> getTest() {
        return test;
    }

    public void setTest(List<TestItem> test) {
        this.test = test;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Suite suite)) return false;
        return getTest().equals(suite.getTest()) && getName().equals(suite.getName()) && Objects.equals(getParallel(), suite.getParallel());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getTest(), getName(), getParallel());
    }
}