package ru.vtb.util.suite_models;

import jakarta.xml.bind.annotation.XmlAccessType;
import jakarta.xml.bind.annotation.XmlAccessorType;
import jakarta.xml.bind.annotation.XmlElement;

import java.util.Objects;

@XmlAccessorType(XmlAccessType.FIELD)
public class Methods{

	@XmlElement(name = "include")
	private Include include;

	public Include getInclude() {
		return include;
	}

	public void setInclude(Include include) {
		this.include = include;
	}

	@Override
	public boolean equals(Object o) {
		if (this == o) return true;
		if (!(o instanceof Methods methods)) return false;
		return getInclude().equals(methods.getInclude());
	}

	@Override
	public int hashCode() {
		return Objects.hash(getInclude());
	}
}