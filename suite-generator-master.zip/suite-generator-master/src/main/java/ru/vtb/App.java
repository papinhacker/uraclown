package ru.vtb;

import ru.vtb.util.FileHelper;
import ru.vtb.util.SuiteGenerator;

import java.io.File;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import static ru.vtb.util.FileHelper.completePath;

public class App {

    private static String tests;
    private static String pathFrom;
    private static String pathTo;
    private static String sep;
    private static String servicesDeploymentLogFileName;

    public static List<File> suiteFiles;

    public static void main(String[] args) {
        initArgs();
        if (servicesDeploymentLogFileName != null) {
            List<String> suites = new LinkedList<>(convertServiceNamesToSuiteNames());
            List<String> singleThread = separateSingleThreadSuites(suites);
            if (!singleThread.isEmpty()) {
                suites.removeAll(singleThread);
                SuiteGenerator.generateSuite(pathTo, singleThread, List.of());
            }
            SuiteGenerator.generateSuite(pathTo, suites, List.of());
        } else if (!tests.isEmpty()) {
            SuiteGenerator.generateSuite(pathTo, parseSuites(tests), parseCases(tests));
        }
        System.out.println("Custom suite(s) successfully generated!");
    }
    //-Dtests="BATM-239,BatmDevices.xml" -Dfrom="../../../TestXML" -Dto="../../../" -jar .\src\main\resources\suitegenerator.jar
    //-DdepLog="dprun.detailed.log" -Dfrom="../../../TestXML" -Dto="../../../" -jar suitegenerator.jar

    private static void initArgs() {
        pathFrom = System.getProperty("from", "TestXML");
        pathFrom = completePath(pathFrom);
        pathTo = System.getProperty("to", ""); // ../../../
        pathTo = completePath(pathTo);
        tests = System.getProperty("tests", "");
        sep = System.getProperty("sep", ",");
        servicesDeploymentLogFileName = System.getProperty("depLog");
        suiteFiles = FileHelper.getAllSuites(pathFrom);
    }

    private static List<String> parseCases(String casesStr) {
        List<String> result = new LinkedList<>();
        if (casesStr.contains(sep)) {
            return Arrays.stream(casesStr.split(sep)).filter(s -> !s.contains(".xml")).toList();
        }
        if (!casesStr.contains(".xml")) {
            result.add(casesStr);
        }
        return result;
    }

    private static List<String> parseSuites(String casesStr) {
        List<String> result = new LinkedList<>();
        if (casesStr.contains(sep)) {
            return Arrays.stream(casesStr.split(sep)).filter(s -> s.contains(".xml")).toList();
        }
        if (casesStr.contains(".xml")) {
            result.add(casesStr);
        }
        return result;
    }

    private static List<String> convertServiceNamesToSuiteNames() {
        List<String> result = new ArrayList<>();
        Set<String> deployedServices = getDeployedServicesNames();
        Set<String> weHaveTestsForTheseServices = new HashSet<>();
        for (File file : suiteFiles) {
            String serviceName = FileHelper.deserializeXmlToObject(file).getName();
            if (deployedServices.contains(serviceName)) {
                result.add(file.getName());
                weHaveTestsForTheseServices.add(serviceName);
            }
        }
        for (String service : weHaveTestsForTheseServices) {
            if (!deployedServices.contains(service)) {
                System.out.printf("There aren't tests for '%s' service%n", service);
            }
        }
        return result;
    }

    private static Set<String> getDeployedServicesNames() {
        List<String> log = new ArrayList<>(FileHelper.readLinesFormFile(new File(servicesDeploymentLogFileName)));
        List<String> readyLines = log.parallelStream().filter(l -> l.contains("is ready and available")).toList();
        Set<String> services = new HashSet<>();
        for (String line : readyLines) {
            Matcher matcher = Pattern.compile("(?<=Application ).*?(?= is ready and available)").matcher(line);
            if (matcher.find()) {
                services.add(matcher.group());
            }
        }
        services.remove("common");
        return services;
    }

    private static List<String> separateSingleThreadSuites(List<String> providedSuiteNames) {
        List<String> result = new ArrayList<>();
        for (String suiteName : providedSuiteNames) {
            String parallel = FileHelper.deserializeXmlToObject(FileHelper.getFileByName(suiteFiles, suiteName)).getParallel();
            if (suiteName.toLowerCase().contains("singlethread") || (parallel != null && parallel.equals("none"))) {
                result.add(suiteName);
            }
        }
        return result;
    }
}
