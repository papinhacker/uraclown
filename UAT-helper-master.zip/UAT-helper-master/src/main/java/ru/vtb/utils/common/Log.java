package ru.vtb.utils.common;

import java.text.SimpleDateFormat;
import java.util.Date;

import static ru.vtb.static_data.EnvConstants.DEBUG;

/**
 * Класс для вывода логов, как в коносль, так и в аллюр, и в логи TestNG
 * <p>
 * Уровни логирования:
 * none = 0
 * error = 1
 * step = 10
 * warning = 25
 * debug = 30
 * trace = 100
 */
public class Log {

    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("(z) HH.mm.ss:SSS");


    private Log() {
    }

    public static void error(Object message) {
        System.out.println("[ERROR] " + DATE_FORMAT.format(new Date())
                + " - " + Thread.currentThread().getStackTrace()[2].getClassName()
                + " [ERROR] " + message.toString());
    }

    public static void debug(Object message) {
        if (DEBUG) {
            System.out.println("[DEBUG] " + DATE_FORMAT.format(new Date())
                    + " - " + Thread.currentThread().getStackTrace()[2].getClassName()
                    + " [DEBUG] " + message.toString());
        }
    }

    public static void info(Object message) {
        System.out.println("[INFO] " + DATE_FORMAT.format(new Date())
                + " - " + Thread.currentThread().getStackTrace()[2].getClassName()
                + " [INFO] " + message.toString());
    }
}
