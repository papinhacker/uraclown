package ru.vtb.utils;

import ru.vtb.utils.sql.SQLHelper;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import static ru.vtb.utils.sql.SQLHelper.BATM_TRANSACTIONS_AGR_SRV;

public class DBHelper {
    public static final SQLHelper batmTransAgrSrv = new SQLHelper(BATM_TRANSACTIONS_AGR_SRV);

    private DBHelper() {
    }

    public static String getCorpNzrAccNum(String mask, String currency, String transType) {
        String query = """
                select account
                from account_bank ab
                where mask_file = '%s'
                and currency = '%s'
                and trans_type = '%s'
                """;
        return batmTransAgrSrv.getFirstFieldFromDB(query.formatted(mask, currency, transType));
    }

    public static String getNotCorpNzrAccNum(String mask, String currency, String transType, String atmId) {
        String query = """
                select ab.account
                from account_bank ab
                inner join devices_acc da on da.branch_code = ab.branch_code
                and da.currency = ab.currency
                where ab.mask_file = '%s'
                and ab.currency = '%s'
                and ab.trans_type = '%s'
                and da.atm_id = '%s'
                """;
        return batmTransAgrSrv.getFirstFieldFromDB(query.formatted(mask, currency, transType, atmId));
    }

    public static String getTerminalAccNum(String atmId) {
        String query = """
                select account from devices_acc da
                where currency = '643'
                and atm_id = '%s'
                """;
        //select account_number
        //from devices_acc da where currency_code = '643'
        //and atm_id = '%s'
        return batmTransAgrSrv.getFirstFieldFromDB(query.formatted(atmId));
    }

    public static Map<String, Object> getBranches(String atmId) {
        String query = """
                select bt.branch_code_transit, bt.branch_code
                from branch_transit bt
                inner join devices_acc da on da.branch_code = bt.branch_code
                where da.currency = '643'
                and da.atm_id = '%s'
                """;
        return batmTransAgrSrv.getRowLinesFromDB(query.formatted(atmId)).get(0);
    }

    public static String getMigratedTransId(String transType, String rrn, String authCode) {
        String query = """
                select tg.id
                from clearing_data cd
                inner join transaction_gp tg on cd.id = tg.trans_id
                where cd.trans_type = '%s'
                and cd.rrn = '%s'
                and cd.auth_code = '%s'
                """;
        return batmTransAgrSrv.getFirstFieldFromDB(query.formatted(transType, rrn, authCode));
    }


    public static List<String> getFirstColumn(List<Map<String, Object>> table) {
        List<String> result = new ArrayList<>();
        table.forEach(s -> result.add(s.values().stream().map(Object::toString).toList().get(0)));
        return result;
    }
}
