package ru.vtb.utils.sql;

import ru.vtb.utils.common.Log;
import ru.vtb.utils.sql.results.ResultSetComposer;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import static ru.vtb.static_data.EnvConstants.*;

public class SQLHelper {

    public static final String BATM_TRANSACTIONS_AGR_SRV = "batm_transactions_agr_srv";

    private final String path;
    private final String login;
    private final String password;

    public SQLHelper(String dbPath) {
        switch (dbPath) {
            case BATM_TRANSACTIONS_AGR_SRV -> {
                path = dbPath;
                login = DB_TRANSACTIONS_AGR_SRV_LOGIN;
                password = DB_TRANSACTIONS_AGR_SRV_PASSWORD;
            }
            default -> throw new UnsupportedOperationException("Database path must be provided");
        }
    }

    private Connection getNewConnection() throws SQLException {
        return DriverManager.getConnection(DB_URI + path, login, password);
    }

    /**
     * Выполняет запрос и возвращает первое значение первой строки и первого столбца
     *
     * @param sqlQuery - SQL запрос для выполнения
     * @param params   - параметры запроса
     * @return набор строк результатов
     */
    public String getFirstFieldFromDB(String sqlQuery, Long timeoutInSecs, Object... params) {
        return getResultsAndCompose(ResultSetComposer.FIRST_ROW_FIRST_FIELD_COMPOSER, sqlQuery, timeoutInSecs, true, params).toString();
    }

    public String getFirstFieldFromDB(String sqlQuery, Object... params) {
        return getFirstFieldFromDB(sqlQuery, 0L, params);
    }

    public List<Map<String, Object>> getRowLinesFromDB(String sqlQuery, Long timeoutInSecs, Boolean log, Object... params) {
        return getResultsAndCompose(ResultSetComposer.ROWS_COMPOSER, sqlQuery, timeoutInSecs, log, params);
    }

    public List<Map<String, Object>> getRowLinesFromDB(String sqlQuery, Boolean log, Object... params) {
        return getRowLinesFromDB(sqlQuery, 0L, log, params);
    }

    public List<Map<String, Object>> getRowLinesFromDB(String sqlQuery, Object... params) {
        return getRowLinesFromDB(sqlQuery, 0L, true, params);
    }

    /**
     * Выполняет запрос и собирает его результаты согласно переданному сборщику
     *
     * @param resultSetComposer - сборщик результатов выполнения запросов
     * @param sqlQuery          - SQL запрос для выполнения
     * @param params            - параметры запроса
     * @return собранную в заданную сборщиком коллекцию результатов выполнения запросов
     */
    private <T> T getResultsAndCompose(ResultSetComposer<T> resultSetComposer, String sqlQuery, Long timeoutInSecs, Boolean log, Object... params) {
        T result = resultSetComposer.createResultStorage();
        String logMessage = "Executing query for database '%s' query - '%s'".formatted(path, sqlQuery.replaceAll("[\t\n]", " "));
        if (log) {
            Log.debug(logMessage);
        }
        try (var connection = getNewConnection();
             var statement = connection.prepareStatement(sqlQuery)) {
            for (int i = 0; i < params.length; i++) {
                statement.setObject(i + 1, params[i]);
            }
            resultSetComposer.composeLines(result, statement.executeQuery());
        } catch (SQLException e) {
            Log.error("Unable to compose result of SQL query. Reason is: " + e.getMessage());
        }
        return result;
    }
}
