package ru.vtb.utils;

import com.opencsv.*;
import com.opencsv.exceptions.CsvException;
import ru.vtb.static_data.CsvLineDto;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;

import static ru.vtb.static_data.EnvConstants.CSV_SEPARATOR;

public class CSVUtils {

    public static List<String[]> parse(File file) {
        CSVParser parser = new CSVParserBuilder().withSeparator('\t').build();
        try (CSVReader reader = new CSVReaderBuilder(new FileReader(file))
                .withCSVParser(parser)
                .build()) {
            return reader.readAll();
        } catch (IOException | CsvException e) {
            throw new RuntimeException("Unable to parse CSV file '%s'. Reason is: %s".formatted(file.getName(), e.getMessage()));
        }
    }

    public static void writeCSVToFile(List<String[]> csv, String pathTo) {
        try (ICSVWriter writer = new CSVWriterBuilder(new FileWriter(pathTo))
                .withSeparator(CSV_SEPARATOR.charAt(0)).build()) {
            writer.writeAll(csv);
        } catch (IOException e) {
            throw new RuntimeException("Unable to write CSV file to '%s'. Reason is: %s".formatted(pathTo, e.getMessage()));
        }
    }

    public static String[] fillCsvLine(CsvLineDto csvLine) {
        return new String[]{
                csvLine.getFilename(),
                csvLine.getMaskName(),
                csvLine.getOperType(),
                csvLine.getAtmId(),
                csvLine.getRrn(),
                csvLine.getAuthCode(),
                csvLine.getAggregationId(),
                csvLine.getMcc(),
                csvLine.getDebit(),
                csvLine.getCredit(),
                csvLine.getAmount(),
                csvLine.getFee(),
                csvLine.getBaseBranch(),
                csvLine.getBranch2(),
                csvLine.getDateTime(),
                csvLine.getTransactionId()};
    }

}
