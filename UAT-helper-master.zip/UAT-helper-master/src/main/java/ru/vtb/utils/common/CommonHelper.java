package ru.vtb.utils.common;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.joda.time.DateTime;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.concurrent.ThreadLocalRandom;

public class CommonHelper {

    private CommonHelper() {
    }

    public static String parseDateFromPatternToAnotherPattern(String originalPattern, String newPattern, String date) {
        try {
            return new SimpleDateFormat(newPattern).format(new SimpleDateFormat(originalPattern).parse(date));
        } catch (ParseException e) {
            throw new RuntimeException("Unable to parse date '%s' from pattern '%s' to pattern '%s'"
                    .formatted(date, originalPattern, newPattern));
        }
    }

    public static String getNumericDayOfYearBeforeCurrentDate() {
        DateTime dateTime = new DateTime();
        return String.format("%03d",
                Integer.parseInt(dateTime.minusDays(ThreadLocalRandom.current().nextInt(1, dateTime.getDayOfYear()))
                        .dayOfYear().getAsString()));
    }

    public static <T> T getRandomFromList(List<T> list) {
        try {
            return list.get(ThreadLocalRandom.current().nextInt(list.size()));
        } catch (IndexOutOfBoundsException | IllegalArgumentException e) {
            throw new RuntimeException("Unable to get random element from list. Reason is: %s".formatted(e.getMessage()));
        }
    }

    public static String serializeToJsonStringIgnoringNullableFields(Object model) {
        try {
            return new ObjectMapper().setSerializationInclusion(JsonInclude.Include.NON_NULL)
                    .writerWithDefaultPrettyPrinter().writeValueAsString(model);
        } catch (JsonProcessingException e) {
            throw new RuntimeException("Не удалось сериализовать POJO в Json. Причина: " + e.getMessage());
        }
    }
}
