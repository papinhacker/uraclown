package ru.vtb.app;

import org.apache.commons.lang3.RandomStringUtils;
import ru.vtb.static_data.*;
import ru.vtb.static_data.models.batm_zod_out_batm_acc_route_s3_event.generators.BatmZodOutBatmAccRouteS3EventRootMessageGenerator;
import ru.vtb.utils.B2LHelper;
import ru.vtb.utils.CSVUtils;
import ru.vtb.utils.FileHelper;
import ru.vtb.utils.common.CommonHelper;
import ru.vtb.utils.common.Log;

import java.io.File;
import java.util.*;

import static ru.vtb.static_data.B2LMask.D_038cto;
import static ru.vtb.static_data.B2LMask._038cts;
import static ru.vtb.static_data.EnvConstants.*;
import static ru.vtb.utils.CSVUtils.fillCsvLine;

public class Main {

    public static final List<String> filenames = new ArrayList<>(Arrays.stream(B2LMask.values()).map(m -> B2LHelper.generateBase2LikeFileName(m, MASK_SUFFIX)).toList());
    public static final Set<String> branches = new HashSet<>();
    public static List<String> migratedAtms;
    public static List<String> notMigratedAtms;
    public static List<String> atms = new ArrayList<>();
    public static List<String> currencies;

    private static int transCount;

    public static void main(String[] args) {
        parseTerminals();
        currencies = parseCurrencies();
        Log.info("Starting UAT generator");
        DBData.lazyInit(currencies);
        var b2ls = generateTransactions();
        Log.info("B2L files were successfully generated! Upload them to S3.");
        if (FILL_CSV) {
            Log.info("Wait until transaction-agr-srv processing is complete. Then press Enter...");
            try (Scanner scanner = new Scanner(System.in)) {
                scanner.nextLine();
            }
        }
        Log.info("Starting processing transactions to CSV:");
        generateCSVFiles(b2ls);
        Log.info("CSV files were successfully generated!");
        generateZodMessages();
        Log.info("File with zod messages was successfully generated!");
    }

    private static void parseTerminals() {
        if (MIGRATED_TERMINALS.isBlank() && NOT_MIGRATED_TERMINALS.isBlank())
            throw new RuntimeException("You need to specify at least one terminal property");
        if (!MIGRATED_TERMINALS.isBlank()) {
            if (MIGRATED_TERMINALS.contains(",")) migratedAtms = List.of(MIGRATED_TERMINALS.split(","));
            else migratedAtms = List.of(MIGRATED_TERMINALS);
        } else {
            migratedAtms = new ArrayList<>();
        }

        if (!NOT_MIGRATED_TERMINALS.isBlank()) {
            if (NOT_MIGRATED_TERMINALS.contains(",")) notMigratedAtms = List.of(NOT_MIGRATED_TERMINALS.split(","));
            else notMigratedAtms = List.of(NOT_MIGRATED_TERMINALS);
        } else {
            notMigratedAtms = new ArrayList<>();
        }
        atms.addAll(migratedAtms);
        atms.addAll(notMigratedAtms);

        if (new HashSet<>(atms).size() != atms.size())
            throw new RuntimeException("Properties 'terminals.migrated' and 'terminals.not.migrated' must have unique values");
    }

    private static List<String> parseCurrencies() {
        List<String> result = new ArrayList<>();
        if (!FOREIGN_CURRENCIES.isBlank()) {
            if (FOREIGN_CURRENCIES.contains(",")) result = List.of(FOREIGN_CURRENCIES.split(","));
            else result = List.of(FOREIGN_CURRENCIES);
            if (new HashSet<>(result).size() != result.size())
                throw new RuntimeException("Property 'foreign.currencies' must have unique values");
        }
        return result;
    }

    public static void generateCSVFiles(List<File> b2ls) {
        List<String[]> migrated = new ArrayList<>();
        List<String[]> notMigrated = new ArrayList<>();

        int processed = 0;
        for (File b2l : b2ls) {
            String filename = b2l.getName();
            var trans = B2LHelper.getBase2LikeTransactionsFromFile(PROJECT_PATH + filename);
            for (TransactionDto dto : trans) {
                CsvLineDto csvLine = new CsvLineDto(dto, filename);
                String atmId = csvLine.getAtmId();
                var line = fillCsvLine(csvLine);

                if (migratedAtms.contains(atmId)) {
                    migrated.add(line);
                } else notMigrated.add(line);
            }
            int currentLoop = trans.size();
            processed = processed + currentLoop;
            Log.info("Processed " + 100 * processed / transCount + "%");
        }
        Comparator<String[]> comp = Comparator.comparing(a -> a[4]);
        migrated.sort(comp);
        notMigrated.sort(comp);

        String[] header = new String[]{"Filename", "Mask", "Operation Type", "Atm id", "RRN", "Auth code", "Aggregation id", "MCC", "Debit", "Credit", "Amount", "Fee", "Base branch", "Branch 2", "Date + Time", "Transaction Id"};

        migrated.add(0, header);
        notMigrated.add(0, header);

        CSVUtils.writeCSVToFile(migrated, PROJECT_PATH + "migrated.csv");
        CSVUtils.writeCSVToFile(notMigrated, PROJECT_PATH + "notMigrated.csv");
    }

    public static List<File> generateTransactions() {
        List<TransactionDto> allTrans = new ArrayList<>();
        List<File> result = new ArrayList<>();
        for (String filename : filenames) {
            var mask = B2LMask.recognize(filename);
            List<TransactionDto> buff = new ArrayList<>();
            List<Bin> bins = filename.contains(D_038cto.getName()) ? Arrays.asList(Bin.values()) : Bin.getOnlyInternalVtbBins();
            for (String atmId : atms) {
                for (Bin bin : bins) {
                    switch (mask) {
                        case _298cto -> {
                            buff.addAll(B2LHelper.getBundleOfWithdrawalAndWithdrawalReversedAndCashInTransactions(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6011")));
                        }
                        case CORP_038cto -> {
                            buff.addAll(B2LHelper.getBundleOfWithdrawalAndWithdrawalReversedTransactions(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6011")));
                            buff.addAll(B2LHelper.getBundleOfWithdrawalAndWithdrawalReversedTransactions(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6012")));
                        }
                        case CORP_038ctd -> {
                            buff.add(B2LHelper.getNewCashInTransactionReference(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6011")));
                            buff.add(B2LHelper.getNewCashInTransactionReference(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6012")));
                        }
                        case OPS_038ctd -> {
                            buff.add(B2LHelper.getNewCashInTransactionReference(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6011")));
                        }
                        case VTB24_038cto -> {
                            buff.addAll(B2LHelper.getBundleOfWithdrawalAndWithdrawalReversedAndCashInTransactions(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6011")));
                            buff.addAll(B2LHelper.getBundleOfWithdrawalAndWithdrawalReversedAndCashInTransactions(Map.of(
                                    ACCOUNT_NUMBER, bin.genRandAccNum(),
                                    TERMINAL_ID, atmId,
                                    MCC, "6012")));
                        }
                        case D_038cto -> {
                            addD_038ctoTrans(buff, atmId, bin, "643");
                            for (String curr : currencies) {
                                addD_038ctoTrans(buff, atmId, bin, curr);
                            }
                        }
                    }
                }
                if (mask.equals(_038cts)) {
                    buff.add(B2LHelper.getNewSelfCollectionCashInTransactionReference(Map.of(
                            TERMINAL_ID, atmId,
                            MCC, "6011")));
                    buff.add(B2LHelper.getNewSelfCollectionCashInTransactionReference(Map.of(
                            TERMINAL_ID, atmId,
                            MCC, "6012")));
                }
            }
            result.add(B2LHelper.generateBase2LikeFile(filename, buff));
            Log.debug(filename + " - " + buff.size());
            allTrans.addAll(buff);
        }
        transCount = allTrans.size();
        Log.debug("all - " + transCount);
        return result;
    }

    private static void addD_038ctoTrans(List<TransactionDto> buff, String atmId, Bin bin, String curremcy) {
        buff.addAll(B2LHelper.getBundleOfCashInAndCashInReversedTransactions(Map.of(
                ACCOUNT_NUMBER, bin.genRandAccNum(),
                TERMINAL_ID, atmId,
                MCC, "6011",
                AMOUNT_FEE, RandomStringUtils.insecure().nextNumeric(0, 5),
                CURRENCY, curremcy)));
        buff.addAll(B2LHelper.getBundleOfCashInAndCashInReversedTransactions(Map.of(
                ACCOUNT_NUMBER, bin.genRandAccNum(),
                TERMINAL_ID, atmId,
                MCC, "6012",
                AMOUNT_FEE, RandomStringUtils.insecure().nextNumeric(0, 5),
                CURRENCY, curremcy)));
        buff.add(B2LHelper.getNewCashInTransactionReference(Map.of(
                ACCOUNT_NUMBER, bin.genRandAccNum(),
                TERMINAL_ID, atmId,
                MCC, "6536",
                AMOUNT_FEE, RandomStringUtils.insecure().nextNumeric(0, 5),
                CURRENCY, curremcy)));
        buff.addAll(B2LHelper.getBundleOfWithdrawalAndWithdrawalReversedTransactions(Map.of(
                ACCOUNT_NUMBER, bin.genRandAccNum(),
                TERMINAL_ID, atmId,
                MCC, "6011",
                AMOUNT_FEE, RandomStringUtils.insecure().nextNumeric(0, 5),
                CURRENCY, curremcy)));
        buff.addAll(B2LHelper.getBundleOfWithdrawalAndWithdrawalReversedTransactions(Map.of(
                ACCOUNT_NUMBER, bin.genRandAccNum(),
                TERMINAL_ID, atmId,
                MCC, "6012",
                AMOUNT_FEE, RandomStringUtils.insecure().nextNumeric(0, 5),
                CURRENCY, curremcy)));
    }

    public static void generateZodMessages() {
        List<String> messages = new ArrayList<>();
        List<String> streams = List.of("1", "2");
        for (String branchCode : branches) {
            for (String streamType : streams) {
                String csvFilename = BatmZodOutBatmAccRouteS3EventRootMessageGenerator.generateRandomAggregatorCSVFilename(Map.of(
                        STREAM_TYPE, streamType,
                        ABS_BRANCH, branchCode));
                var zodMsg = BatmZodOutBatmAccRouteS3EventRootMessageGenerator.generate(Map.of(
                        CSV_FILENAME, csvFilename,
                        STREAM_TYPE, streamType,
                        ABS_BRANCH, branchCode
                ));
                messages.add(CommonHelper.serializeToJsonStringIgnoringNullableFields(zodMsg));
                messages.add("\n");
            }
        }
        FileHelper.writeLinesToFile(messages, PROJECT_PATH + "zodMessages.txt");
    }

}
