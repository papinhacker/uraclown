package ru.vtb.static_data;

import lombok.Data;
import ru.vtb.app.Main;
import ru.vtb.utils.DBHelper;
import ru.vtb.utils.common.CommonHelper;

import java.util.Locale;

import static ru.vtb.static_data.EnvConstants.FILL_CSV;

@Data
public class CsvLineDto {
    TransactionDto dto;
    String filename;
    String maskName;
    String operType;
    String atmId;
    String rrn;
    String authCode;
    String aggregationId;
    String mcc;
    String debit; //accNumber
    String credit; //accNumberNzr
    String amount;
    String fee;
    String baseBranch;
    String branch2;
    String dateTime;
    String transactionId;

    boolean isCorp;
    boolean isReversal;
    String currency;

    public CsvLineDto(TransactionDto dto, String filename) {
        this.dto = dto;
        this.filename = filename;
        B2LMask mask = B2LMask.recognize(filename);
        maskName = mask.getName();
        atmId = dto.getTerminalID().trim();
        amount = String.format(Locale.US, "%.2f", Double.parseDouble(dto.getDestinationAmount()) / 100);
        fee = dto.getSurchargeAmount() != null ? String.valueOf(Double.parseDouble(dto.getSurchargeAmount()) / 100) : "0.00";
        rrn = dto.getRetrievalReferenceNumber();
        authCode = dto.getAuthorizationCode();
        if (mask.equals(B2LMask._038cts)) {
            String tag = dto.getF1115Tag();
            authCode = tag.substring(0, 6);
            rrn = tag.substring(6);
            amount = String.format(Locale.US, "%.2f", Double.parseDouble(dto.getSelfCollectionAmount()) / 100);
        }
        mcc = dto.getMerchantCategoryCode();
        isCorp = mask.isCorp();
        isReversal = false;
        currency = dto.getDestinationCurrencyCode();
        String aggPrefix;
        String accNum = DBHelper.getTerminalAccNum(atmId);
        switch (dto.getTC()) {
            case "06" -> {
                operType = "Cash-In";
                aggPrefix = isCorp ? "WAY4_P_" : "BATM_P_";
                debit = accNum;
                credit = isCorp ? DBData.getCorpNzrAccNum(maskName, operType) : DBData.getNotCorpNzrAccNum(maskName, operType, atmId, currency);
            }
            case "07" -> {
                operType = "Cash-Withdrawal";
                aggPrefix = isCorp ? "WAY4_P_" : "BATM_P_";
                debit = isCorp ? DBData.getCorpNzrAccNum(maskName, operType) : DBData.getNotCorpNzrAccNum(maskName, operType, atmId, currency);
                credit = accNum;
            }
            case "26" -> {
                operType = "Reversal-Cash-In";
                aggPrefix = isCorp ? "WAY4_R_" : "BATM_R_";
                isReversal = true;
                debit = isCorp ? DBData.getCorpNzrAccNum(maskName, operType) : DBData.getNotCorpNzrAccNum(maskName, operType, atmId, currency);
                credit = accNum;
            }
            case "27" -> {
                operType = "Reversal-Cash-Withdrawal";
                aggPrefix = isCorp ? "WAY4_R_" : "BATM_R_";
                isReversal = true;
                debit = accNum;
                credit = isCorp ? DBData.getCorpNzrAccNum(maskName, operType) : DBData.getNotCorpNzrAccNum(maskName, operType, atmId, currency);
            }
            default -> {
                String error = "error";
                operType = error;
                aggPrefix = error;
                debit = error;
                credit = error;
            }
        }
        aggregationId = aggPrefix + rrn + authCode;
        dateTime = CommonHelper.parseDateFromPatternToAnotherPattern("yyyyMMddHHmmss",
                "yyyy-MM-dd HH:mm:ss",
                dto.getTransactionDate() + dto.getTransactionTime());
        var branches = DBData.getBranchMapping(atmId);
        baseBranch = branches.getBaseBranch();
        branch2 = branches.getBranch2();
        if (FILL_CSV && Main.migratedAtms.contains(atmId)) {
            transactionId = DBHelper.getMigratedTransId(operType, rrn, authCode);
        }
    }
}
