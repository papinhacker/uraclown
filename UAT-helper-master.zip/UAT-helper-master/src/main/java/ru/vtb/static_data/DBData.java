package ru.vtb.static_data;

import org.apache.commons.lang3.StringUtils;
import ru.vtb.app.Main;
import ru.vtb.utils.DBHelper;

import java.util.ArrayList;
import java.util.List;

public class DBData {

    private static final List<NzrAccount> nzrAccs = new ArrayList<>();
    private static final List<NzrAccount> corpNzrAccs = new ArrayList<>();
    private static final List<BranchMapping> branches = new ArrayList<>();

    public static void lazyInit(List<String> currs) {
        for (String curr : currs) {
            initForeignExchangeNzrAccs(curr);
        }
        initNzrAccs();
        initBranches();
    }

    private static void initNzrAccs() {
        for (String filename : Main.filenames) {
            B2LMask mask = B2LMask.recognize(filename);
            for (String transType : mask.getOperTypes()) {
                String maskName = mask.getName();
                for (String atmId : Main.atms) {
                    String accNum = mask.isCorp() ?
                            DBHelper.getCorpNzrAccNum(maskName, "643", transType) :
                            DBHelper.getNotCorpNzrAccNum(maskName, "643", transType, atmId);
                    checkNzrAccNumAvailability(accNum);
                    if (mask.isCorp()) {
                        corpNzrAccs.add(NzrAccount.builder()
                                .operType(transType)
                                .maskName(maskName)
                                .accNum(accNum)
                                .currency("643")
                                .build());
                    } else {
                        nzrAccs.add(NzrAccount.builder()
                                .operType(transType)
                                .maskName(maskName)
                                .atmId(atmId)
                                .accNum(accNum)
                                .currency("643")
                                .build());
                    }
                }
            }
        }
    }

    private static void initForeignExchangeNzrAccs(String foreignCurrency) {
        B2LMask mask = B2LMask.D_038cto;
        for (String transType : mask.getOperTypes()) {
            String maskName = mask.getName();
            for (String atmId : Main.atms) {
                String accNum = DBHelper.getNotCorpNzrAccNum(maskName, foreignCurrency, transType, atmId);
                checkNzrAccNumAvailability(accNum);
                nzrAccs.add(NzrAccount.builder()
                        .operType(transType)
                        .maskName(maskName)
                        .atmId(atmId)
                        .accNum(accNum)
                        .currency(foreignCurrency)
                        .build());

            }
        }
    }


    private static void checkNzrAccNumAvailability(String accNum) {
        if (StringUtils.isEmpty(accNum)) {
            throw new RuntimeException("Account number from last SQL query must be exists");
        }
    }

    private static void initBranches() {
        for (String atm : Main.atms) {
            var buff = DBHelper.getBranches(atm);
            if (buff.isEmpty()) throw new RuntimeException("Branches for atm id '%s' must be exist".formatted(atm));
            branches.add(BranchMapping.builder()
                    .atmId(atm)
                    .baseBranch(buff.get("branch_code_transit").toString())
                    .branch2(buff.get("branch_code").toString())
                    .build());
            Main.branches.add(buff.get("branch_code_transit").toString());
        }
    }

    public static String getNotCorpNzrAccNum(String mask, String transType, String atmId, String currency) {
        for (NzrAccount acc : nzrAccs) {
            if (acc.getMaskName().equals(mask) && acc.getOperType().equals(transType) && acc.getAtmId().equals(atmId) && acc.getCurrency().equals(currency)) {
                return acc.getAccNum();
            }
        }
        throw new RuntimeException("Unable to find nzr acc number for mask '%s', trans type '%s' and atm id '%s'".formatted(mask, transType, atmId));
    }

    public static String getCorpNzrAccNum(String mask, String transType) {
        for (NzrAccount acc : corpNzrAccs) {
            if (acc.getMaskName().equals(mask) && acc.getOperType().equals(transType)) {
                return acc.getAccNum();
            }
        }
        throw new RuntimeException("Unable to find nzr CORP acc number for mask '%s', trans type '%s'".formatted(mask, transType));
    }

    public static BranchMapping getBranchMapping(String atmId) {
        for (BranchMapping bm : branches) {
            if (bm.getAtmId().equals(atmId)) {
                return bm;
            }
        }
        throw new RuntimeException("Unable to find branches for atm '%s'".formatted(atmId));
    }

}
