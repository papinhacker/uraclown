package ru.vtb.static_data;


import ru.vtb.utils.B2LHelper;

import java.util.HashSet;
import java.util.Set;

public enum B2LMask {

    _298cto("298cto", new HashSet<>(Set.of("Cash-In", "Cash-Withdrawal", "Reversal-Cash-Withdrawal"))),
    CORP_038cto("CORP_038cto", new HashSet<>(Set.of("Cash-Withdrawal", "Reversal-Cash-Withdrawal"))),
    CORP_038ctd("CORP_038ctd", new HashSet<>(Set.of("Cash-In"))),
    VTB24_038cto("VTB24_038cto", new HashSet<>(Set.of("Cash-In", "Cash-Withdrawal", "Reversal-Cash-Withdrawal"))),
    OPS_038ctd("OPS_038ctd", new HashSet<>(Set.of("Cash-In"))),
    D_038cto("D_038cto", new HashSet<>(Set.of("Cash-In", "Cash-Withdrawal", "Reversal-Cash-In", "Reversal-Cash-Withdrawal"))),
    _038cts("038cts", new HashSet<>(Set.of("Cash-In")));

    private final String name;
    private final Set<String> operTypes;

    B2LMask(String name, Set<String> operTypes) {
        this.name = name;
        this.operTypes = operTypes;
    }

    public static B2LMask recognize(String b2lFilename) {
        b2lFilename = B2LHelper.substringFileMask(b2lFilename);
        for (B2LMask mask : values()) {
            if (b2lFilename.equals(mask.name)) {
                return mask;
            }
        }
        throw new RuntimeException("Unable to recognize file mask of file - " + b2lFilename);
    }

    public boolean isCorp() {
        return this.equals(CORP_038cto) || this.equals(CORP_038ctd) || this.equals(_038cts);
    }

    public String getName() {
        return this.name;
    }

    public Set<String> getOperTypes() {
        return this.operTypes;
    }

}
