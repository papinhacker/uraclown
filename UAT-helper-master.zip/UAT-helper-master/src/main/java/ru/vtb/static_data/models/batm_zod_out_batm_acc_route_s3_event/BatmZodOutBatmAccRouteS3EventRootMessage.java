package ru.vtb.static_data.models.batm_zod_out_batm_acc_route_s3_event;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class BatmZodOutBatmAccRouteS3EventRootMessage {

    @JsonProperty("messageId")
    private String messageId;

    @JsonProperty("eventName")
    private String eventName;

    @JsonProperty("description")
    private String description;

    @JsonProperty("operdayDate")
    private String operdayDate;

    @JsonProperty("branchCode")
    private String branchCode;

    @JsonProperty("sessionNumber")
    private String sessionNumber;

    @JsonProperty("systemCode")
    private String systemCode;

    @JsonProperty("systemName")
    private String systemName;

    @JsonProperty("parameters")
    private List<ParametersItem> parameters;
}