package ru.vtb.static_data;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class BranchMapping {
    private String atmId;

    private String baseBranch;
    private String branch2;
}
