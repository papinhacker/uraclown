package ru.vtb.static_data;

public record Terminal(String id, boolean isMigrated) {
}
