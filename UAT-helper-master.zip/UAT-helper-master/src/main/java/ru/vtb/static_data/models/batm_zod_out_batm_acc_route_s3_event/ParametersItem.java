package ru.vtb.static_data.models.batm_zod_out_batm_acc_route_s3_event;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ParametersItem {

    @JsonProperty("key")
    private String key;

    @JsonProperty("value")
    private String value;
}