package ru.vtb.static_data;

import ru.vtb.utils.common.Log;

import java.io.FileReader;
import java.io.IOException;
import java.nio.file.FileSystems;
import java.util.Properties;

public class EnvConstants {

    public static final String FILE_SEPARATOR = FileSystems.getDefault().getSeparator();
    public static final String PROJECT_DIRECTORY = System.getProperty("user.dir");
    public static final String PROJECT_PATH = PROJECT_DIRECTORY + FILE_SEPARATOR;
    public static final String CORP_TO_JSON = "CORP_TO_JSON";
    public static final String FL_TO_JSON = "FL_TO_JSON";
    public static final String TERMINAL_TYPE = "TERMINAL_TYPE";
    public static final String ACCOUNT_NUMBER = "ACCOUNT_NUMBER";
    public static final String TERMINAL_ID = "TERMINAL_ID";
    public static final String MCC = "MCC";
    public static final String RRN = "RRN";
    public static final String CURRENCY = "CURRENCY";
    public static final String AUTH_CODE = "AUTH_CODE";
    public static final String AMOUNT_FEE = "AMOUNT_FEE";
    public static final String CSV_FILENAME = "CSV_FILENAME";
    public static final String STREAM_TYPE = "STREAM_TYPE";
    public static final String ABS_BRANCH = "ABS_BRANCH";


    private static final String PROP_PATH = System.getProperty("propsPath", "uat.properties");
    protected static final Properties PROPERTIES = getPropsForEnv();
    /* database data */
    public static final String DB_URI = getProperty("db.uri");
    public static final String DB_TRANSACTIONS_AGR_SRV_LOGIN = getProperty("db.transagrsrv.login");
    public static final String DB_TRANSACTIONS_AGR_SRV_PASSWORD = getProperty("db.transagrsrv.password");
    /* generator params */
    public static final String MASK_SUFFIX = getProperty("mask.suffix");
    public static final String MIGRATED_TERMINALS = getProperty("terminals.migrated");
    public static final String NOT_MIGRATED_TERMINALS = getProperty("terminals.not.migrated");
    public static final String CSV_SEPARATOR = getProperty("csv.separator");
    public static final String FOREIGN_CURRENCIES = getProperty("foreign.currencies");
    public static final boolean FILL_CSV = Boolean.parseBoolean(getProperty("fill.transaction.id"));
    /* debug params */
    public static final boolean DEBUG = Boolean.parseBoolean(getProperty("debug"));

    private static Properties getPropsForEnv() {
        Properties properties;

        try (FileReader reader = new FileReader(PROP_PATH)) {
            properties = new Properties();
            properties.load(reader);
        } catch (IOException e) {
            String err = String.format("Unable to read properties file. Reason is '%s'", e.getMessage());
            Log.error(err);
            throw new RuntimeException(err);
        }
        return properties;
    }

    protected static String getProperty(String key) {
        String prop = PROPERTIES.getProperty(key);
        if (prop == null) {
            throw new RuntimeException("Property '%s' must be provided in '%s'".formatted(key, PROP_PATH));
        }
        return prop;
    }
}
