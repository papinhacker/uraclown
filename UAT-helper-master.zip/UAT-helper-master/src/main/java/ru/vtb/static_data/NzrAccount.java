package ru.vtb.static_data;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class NzrAccount {
    private String maskName;
    private String operType;
    private String atmId;
    private String currency;

    private String accNum;
}
