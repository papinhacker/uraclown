package ru.vtb.static_data.models.batm_zod_out_batm_acc_route_s3_event.generators;

import org.apache.commons.lang3.RandomStringUtils;
import ru.vtb.static_data.EnvConstants;
import ru.vtb.static_data.models.batm_zod_out_batm_acc_route_s3_event.BatmZodOutBatmAccRouteS3EventRootMessage;
import ru.vtb.static_data.models.batm_zod_out_batm_acc_route_s3_event.ParametersItem;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class BatmZodOutBatmAccRouteS3EventRootMessageGenerator {

    private static final String BANKING_DATE = new SimpleDateFormat("yyyy-MM-dd").format(new Date());

    public static BatmZodOutBatmAccRouteS3EventRootMessage generate(Map<String, String> fields) {
        String csvFilename = fields.getOrDefault(EnvConstants.CSV_FILENAME, generateRandomAggregatorCSVFilename(Map.of()));
        String streamType = fields.getOrDefault(EnvConstants.STREAM_TYPE, "error");
        String branchCode = fields.getOrDefault(EnvConstants.ABS_BRANCH, "error");

        return BatmZodOutBatmAccRouteS3EventRootMessage.builder()
                .messageId(UUID.randomUUID().toString())
                .eventName("BATM-AggLoad")
                //убрали в новой поставновке.
                //.eventDate(CommonHelper.getCurrentDateInFormat("yyyy-MM-dd'T'HH:mm:ss.SSS'Z'"))
                .description("Выгрузка в агрегатор")
                .operdayDate(BANKING_DATE)
                .systemCode("2213")
                .systemName("Бэк-Офис Ус и АДМ")
                .branchCode(branchCode)
                .parameters(List.of(
                        ParametersItem.builder()
                                .key("fileName")
                                .value(csvFilename)
                                .build(),
                        ParametersItem.builder()
                                .key("flowType")
                                .value(streamType)
                                .build(),
                        ParametersItem.builder()
                                .key("bankingDate")
                                .value(BANKING_DATE)
                                .build()))
                .build();
    }

    public static String generateRandomAggregatorCSVFilename(Map<String, String> fields) {
        String branchCode = fields.getOrDefault(EnvConstants.ABS_BRANCH, "error");
        String streamType = fields.getOrDefault(EnvConstants.STREAM_TYPE, "error");
        String date = new SimpleDateFormat("yyyyMMdd").format(new Date());
        return "BATMWATRN_%s_%s_%s_%s.csv"
                .formatted(streamType, branchCode, date, RandomStringUtils.insecure().nextNumeric(2));
    }
}
